package com.newlecture.proj2;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Scanner;

public class MenuRepository {
		
	private String dataSource;
	
	public MenuRepository() {
		dataSource = "res/menu.csv";
	}
	
	public MenuList findAll() throws IOException {
		MenuList list = new MenuList();
		
		FileInputStream fis = new FileInputStream(dataSource);
		Scanner scan = new Scanner(fis);
		scan.nextLine();
		
		while(scan.hasNextLine()) {
			Menu menu = new Menu();
			String line = scan.nextLine();
			String[] tokens = line.split(",");
			
			menu.id = Integer.parseInt(tokens[0]);
			menu.korName = tokens[1];
			menu.engName = tokens[2];
			menu.price = Integer.parseInt(tokens[3]);
			menu.like = Integer.parseInt(tokens[4]);
			menu.img = tokens[5];
			
			list.add(menu);			
		}
						
		scan.close();
		fis.close();		
		
		return list;
	}

	public void save(Menu menu) throws IOException {
		FileOutputStream fos = new FileOutputStream(dataSource, true);
		PrintStream fout = new PrintStream(fos);
		
		fout.printf(
			"\n%d,%s,%s,%d,%d,%s",
			menu.id, menu.korName, menu.engName, menu.price, menu.like, menu.img);
		
		fout.close();
		fos.close();
	}

}
