package com.newlecture.proj2;

public class MenuList {
	private int count;
	private int index;
	private Menu[] menus;
	
	public MenuList() {
		count = 5;
		index = 0;
		menus = new Menu[count];
	}
	
	public void add(Menu menu) {
		menus[index++] = menu;
	}
	
	public int size() {
		return index;
	}

	public Menu get(int index) {
		
		return menus[index];
	}
}
