package com.newlecture.proj2;

import java.io.IOException;

public class App {

	public static void main(String[] args) throws IOException {
		MenuUI menuUI = new MenuUI();
				
		menuUI.index();
//		menuUI.list();
//		menuUI.edit();
//		menuUI.reg();
//		menuUI.detail();
	}

}
