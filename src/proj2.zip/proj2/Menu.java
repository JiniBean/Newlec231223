package com.newlecture.proj2;

public class Menu {
	int id;
	String korName;
	String engName;
	int price;
	int like;
	String img;
}
